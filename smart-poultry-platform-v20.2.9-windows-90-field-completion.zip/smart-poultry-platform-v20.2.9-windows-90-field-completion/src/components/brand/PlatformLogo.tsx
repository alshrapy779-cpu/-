import React from 'react';

interface PlatformLogoProps { className?: string; compact?: boolean; }

/**
 * V19.4 vector identity. Shield = governance, poultry silhouette = sector,
 * medical pulse + digital nodes = veterinary intelligence and traceability.
 * Pure SVG keeps the mark sharp on Android, desktop, print and QR documents.
 */
export const PlatformLogo: React.FC<PlatformLogoProps> = ({ className='w-12 h-12', compact=false }) => (
  <svg viewBox="0 0 120 120" className={className} role="img" aria-label="شعار المنصة الوطنية للسيادة البيطرية والداجنة الذكية">
    <defs>
      <linearGradient id="v194shield" x1="15" y1="8" x2="104" y2="112" gradientUnits="userSpaceOnUse"><stop stopColor="#073B36"/><stop offset=".52" stopColor="#0B7A62"/><stop offset="1" stopColor="#075985"/></linearGradient>
      <linearGradient id="v194gold" x1="35" y1="30" x2="88" y2="88" gradientUnits="userSpaceOnUse"><stop stopColor="#F7DC96"/><stop offset="1" stopColor="#D49B32"/></linearGradient>
      <filter id="v194shadow" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy="7" stdDeviation="6" floodColor="#020617" floodOpacity=".42"/></filter>
    </defs>
    <path d="M60 7 105 22v33c0 29-17 49.5-45 58C32 104.5 15 84 15 55V22L60 7Z" fill="url(#v194shield)" filter="url(#v194shadow)"/>
    <path d="M60 14 98 27v28c0 24.1-13.6 41.8-38 50.2C35.6 96.8 22 79.1 22 55V27L60 14Z" fill="none" stroke="#8CF5D0" strokeOpacity=".26" strokeWidth="2"/>
    <circle cx="60" cy="56" r="34" fill="#031B1D" fillOpacity=".24" stroke="#DDFDF3" strokeOpacity=".12"/>

    {/* refined bird profile */}
    <path d="M36 70c5.7-20.2 17.8-32.7 34.8-32.7 8.1 0 14.8 3.1 19.4 8.8-7.5.2-13.4 2.4-17.7 6.5 7.8.8 13.5 3.6 17.2 8.7-6.4 8.6-16.3 13.5-29.2 13.5-10.4 0-18.6-1.6-24.5-4.8Z" fill="#F8FFFD"/>
    <path d="m67.5 37.4 4.3-9 4.6 8.3 7.5-5.5-1.6 10" fill="url(#v194gold)" stroke="#F7D27A" strokeWidth="1.8" strokeLinejoin="round"/>
    <circle cx="72.7" cy="47.6" r="2.7" fill="#042F2E"/>
    <path d="m88.8 51.6 12 5.3-12 5.1Z" fill="url(#v194gold)"/>

    {/* veterinary pulse */}
    {!compact && <path d="M31 82h13l4.7-8.5 7.2 17 8.1-14 5.2 7.2h17" fill="none" stroke="#F4C866" strokeWidth="3.3" strokeLinecap="round" strokeLinejoin="round"/>}
    <circle cx="31" cy="82" r="2.4" fill="#F4C866"/><circle cx="86" cy="83.7" r="2.4" fill="#F4C866"/>

    {/* digital trace nodes */}
    <circle cx="29" cy="39" r="2.2" fill="#67E8F9"/><circle cx="26" cy="50" r="1.5" fill="#67E8F9" fillOpacity=".75"/><path d="M30 39h8M27 50h7" stroke="#67E8F9" strokeOpacity=".5" strokeWidth="1.5"/>
  </svg>
);
