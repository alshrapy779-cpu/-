import React from 'react';
import {
  Bell,
  BriefcaseBusiness,
  Bot,
  Calculator,
  DollarSign,
  FileText,
  Home,
  Menu,
  Moon,
  QrCode,
  Settings2,
  ShoppingBag,
  Smartphone,
  Stethoscope,
  Sun,
  Syringe,
  Users,
  MessageCircleMore,
  ClipboardList,
  UserCircle2,
  Wifi,
  WifiOff,
  X
} from 'lucide-react';
import { PlatformLogo } from './brand/PlatformLogo';
import { APP_RELEASE_LABEL } from '../config/appVersion';

export type AppView =
  | 'home'
  | 'enterprise'
  | 'farmer'
  | 'vet'
  | 'calculator'
  | 'passport'
  | 'srs'
  | 'marketplace'
  | 'workers'
  | 'vaccines'
  | 'admin'
  | 'finance'
  | 'communications'
  | 'managed';

interface HeaderProps {
  activeView: AppView;
  onViewChange: (view: AppView) => void;
  isOnline: boolean;
  onToggleOnline: () => void;
  pendingCasesCount: number;
  onOpenAIGuidance: () => void;
  theme?: 'dark' | 'light';
  onToggleTheme?: () => void;
  onOpenSettings?: () => void;
  aiShortcutEnabled?: boolean;
  currentUserName?: string;
  currentUserRole?: string;
  onOpenAccount?: () => void;
  allowedViews?: AppView[];
}

const primaryNav: Array<{ id: AppView; label: string; icon: React.ReactNode; badge?: 'cases' }> = [
  { id: 'home', label: 'الرئيسية', icon: <Home className="w-4 h-4"/> },
  { id: 'enterprise', label: 'مساحة العمل', icon: <BriefcaseBusiness className="w-4 h-4"/> },
  { id: 'marketplace', label: 'السوق والتوريدات', icon: <ShoppingBag className="w-4 h-4"/> },
  { id: 'communications', label: 'التواصل', icon: <MessageCircleMore className="w-4 h-4"/> }
];

export const Header: React.FC<HeaderProps> = ({
  activeView,
  onViewChange,
  isOnline,
  onToggleOnline,
  pendingCasesCount,
  onOpenAIGuidance,
  theme = 'dark',
  onToggleTheme,
  onOpenSettings,
  aiShortcutEnabled = true,
  currentUserName = 'مستخدم المنصة',
  currentUserRole = '',
  onOpenAccount,
  allowedViews
}) => {
  const [mobileMoreOpen, setMobileMoreOpen] = React.useState(false);
  return (
    <>
      <header className="no-print spp-header sticky top-0 z-50" dir="rtl">
        <div className="spp-identity-strip">
          <div className="flex items-center gap-2 min-w-0">
            <span className="w-5 h-5 rounded-full bg-emerald-500/15 text-emerald-300 grid place-items-center text-[10px]">🇾🇪</span>
            <span className="hidden sm:inline text-emerald-300 font-bold">الجمهورية اليمنية</span>
            <span className="hidden lg:inline text-slate-500">• منظومة الأمن الغذائي والسيادة البيطرية والداجنة الذكية</span>
          </div>
          <div className="flex items-center gap-1.5">
            {aiShortcutEnabled && <button onClick={onOpenAIGuidance} className="spp-top-action"><Bot className="w-3.5 h-3.5"/><span className="hidden sm:inline">المساعد البيطري</span></button>}
            <button onClick={onToggleTheme} className="spp-top-action" title="تبديل الوضع">{theme==='light'?<Moon className="w-3.5 h-3.5"/>:<Sun className="w-3.5 h-3.5"/>}</button>
            <button onClick={onOpenSettings} className="spp-top-action" title="الإعدادات"><Settings2 className="w-3.5 h-3.5"/></button>
            <button onClick={onToggleOnline} className={`spp-connectivity ${isOnline?'is-online':'is-offline'}`} title="حالة الاتصال">{isOnline?<Wifi className="w-3.5 h-3.5"/>:<WifiOff className="w-3.5 h-3.5"/>}<span className="hidden sm:inline">{isOnline?'متصل':'أوفلاين'}</span></button>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-3 flex items-center justify-between gap-4">
          <button onClick={() => onViewChange('home')} className="flex items-center gap-3 min-w-0 text-right group">
            <div className="spp-logo-shell"><PlatformLogo className="w-12 h-12 sm:w-14 sm:h-14"/></div>
            <div className="min-w-0">
              <div className="flex items-center gap-2 min-w-0"><h1 className="text-sm sm:text-[17px] font-black text-white truncate">المنصة الوطنية للسيادة البيطرية والداجنة الذكية</h1><span className="hidden xl:inline spp-version-pill">{APP_RELEASE_LABEL}</span></div>
              <div className="hidden sm:flex items-center gap-2 mt-1 text-[10px]"><span className="text-emerald-300 font-black tracking-wide">SMART POULTRY PLATFORM</span><span className="text-slate-600">•</span><span className="text-slate-400">Enterprise Veterinary Network</span></div>
            </div>
          </button>

          <div className="hidden md:flex items-center gap-1.5">
            <button onClick={onOpenAccount} className="spp-user-chip" title="الحساب الحالي"><UserCircle2 className="w-4 h-4"/><span className="text-right"><b>{currentUserName}</b><small>{currentUserRole}</small></span></button>
            <button className="spp-icon-button relative" title="التنبيهات"><Bell className="w-4 h-4"/>{pendingCasesCount>0&&<span className="absolute -top-1 -left-1 w-4 h-4 rounded-full bg-rose-500 text-[8px] text-white font-black grid place-items-center">{pendingCasesCount}</span>}</button>
            <button className="spp-icon-button" onClick={onOpenSettings} title="الإعدادات"><Settings2 className="w-4 h-4"/></button>
          </div>
        </div>

        <div className="hidden md:block border-t border-slate-800/80">
          <nav className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2 flex items-center gap-1.5 overflow-x-auto spp-main-nav">
            {primaryNav.filter(item => !allowedViews || allowedViews.includes(item.id)).map(item => <NavButton key={item.id} active={activeView===item.id} label={item.label} icon={item.icon} badge={item.badge==='cases'?pendingCasesCount:0} onClick={()=>onViewChange(item.id)}/>)}
            <div className="h-6 w-px bg-slate-800 mx-0.5"/>
            <NavButton active={activeView==='passport'} label="الجواز" icon={<QrCode className="w-4 h-4"/>} onClick={()=>onViewChange('passport')}/>
            <NavButton active={activeView==='srs'} label="SRS" icon={<FileText className="w-4 h-4"/>} onClick={()=>onViewChange('srs')}/>
          </nav>
        </div>
      </header>

      {mobileMoreOpen && <div className="md:hidden fixed inset-0 z-[70] bg-slate-950/70" onClick={()=>setMobileMoreOpen(false)}><div dir="rtl" className="absolute bottom-[5.3rem] left-3 right-3 rounded-3xl border border-slate-700 bg-[#081b20] p-3 shadow-2xl" onClick={e=>e.stopPropagation()}><div className="flex items-center justify-between mb-3"><strong className="text-xs text-white">أقسام المنصة</strong><button onClick={()=>setMobileMoreOpen(false)} className="spp-icon-button"><X className="w-4 h-4"/></button></div><div className="grid grid-cols-3 gap-2">{[
        ['managed','إدارة المزارع',<ClipboardList className="w-4 h-4"/>],['finance','المالية القديمة',<DollarSign className="w-4 h-4"/>],['communications','التواصل',<MessageCircleMore className="w-4 h-4"/>],['workers','العمالة القديمة',<Users className="w-4 h-4"/>],['vaccines','اللقاحات',<Syringe className="w-4 h-4"/>],['calculator','الخسائر',<Calculator className="w-4 h-4"/>],['passport','الجواز',<QrCode className="w-4 h-4"/>],['admin','الإدارة',<DollarSign className="w-4 h-4"/>],['srs','SRS',<FileText className="w-4 h-4"/>]
      ].filter(([id]) => !allowedViews || allowedViews.includes(id as AppView)).map(([id,label,icon])=><MobileMoreButton key={String(id)} label={String(label)} icon={icon as React.ReactNode} onClick={()=>{onViewChange(id as AppView);setMobileMoreOpen(false);}}/>)}</div></div></div>}

      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-[75] mobile-bottom-safe px-2.5 pt-2 spp-mobile-nav" dir="rtl">
        <div className="grid grid-cols-5 gap-1.5 max-w-md mx-auto">
          <MobileNav active={activeView==='home'} label="الرئيسية" icon={<Home/>} onClick={()=>onViewChange('home')}/>
          <MobileNav active={activeView==='enterprise'} label="العمل" icon={<BriefcaseBusiness/>} onClick={()=>onViewChange('enterprise')}/>
          <MobileNav active={activeView==='vet'} label="الطبيب" icon={<Stethoscope/>} onClick={()=>onViewChange('vet')}/>
          {aiShortcutEnabled ? <MobileNav active={false} label="المساعد" icon={<Bot/>} accent onClick={onOpenAIGuidance}/> : <MobileNav active={activeView==='marketplace'} label="السوق" icon={<ShoppingBag/>} onClick={()=>onViewChange('marketplace')}/>} 
          <MobileNav active={mobileMoreOpen} label="المزيد" icon={<Menu/>} onClick={()=>setMobileMoreOpen(v=>!v)}/>
        </div>
      </nav>
    </>
  );
};

const NavButton: React.FC<{active:boolean;label:string;icon:React.ReactNode;badge?:number;onClick:()=>void}> = ({active,label,icon,badge=0,onClick}) => <button onClick={onClick} className={`spp-nav-button ${active?'is-active':''}`}><span className="text-current">{icon}</span><span>{label}</span>{badge>0&&<span className="spp-nav-badge">{badge}</span>}</button>;
const MobileMoreButton: React.FC<{label:string;icon:React.ReactNode;onClick:()=>void}> = ({label,icon,onClick}) => <button onClick={onClick} className="rounded-2xl bg-slate-900 border border-slate-700 px-2 py-3 text-[10px] font-black text-slate-200 flex flex-col items-center gap-1.5"><span className="text-emerald-300">{icon}</span><span>{label}</span></button>;
const MobileNav: React.FC<{active:boolean;label:string;icon:React.ReactNode;onClick:()=>void;accent?:boolean}> = ({active,label,icon,onClick,accent}) => <button onClick={onClick} className={`spp-mobile-nav-button ${active?'is-active':''} ${accent?'is-accent':''}`}><span className="[&>svg]:w-4 [&>svg]:h-4">{icon}</span><span>{label}</span></button>;
