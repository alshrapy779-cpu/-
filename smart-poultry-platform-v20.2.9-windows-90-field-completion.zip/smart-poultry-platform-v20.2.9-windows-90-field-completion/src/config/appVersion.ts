export const APP_VERSION = '20.2.9';
export const APP_RELEASE_LABEL = 'V20.2.9 • Windows 90% Field-by-Field Completion';
export const APP_CODENAME = 'Windows 90% Field-by-Field Completion';
