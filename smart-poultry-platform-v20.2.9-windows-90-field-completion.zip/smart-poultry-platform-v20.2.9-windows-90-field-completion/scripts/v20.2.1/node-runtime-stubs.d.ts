declare const process:any;
declare const Buffer:any;
type Buffer=any;
declare module 'node:crypto' { const x:any; export default x; }
declare module 'node:fs' { const x:any; export default x; }
declare module 'node:path' { const x:any; export default x; }
