# حالة اقتراحات التطوير V19.4

## مكتمل/مفعّل في V19.4
1. Customer/Farm Onboarding: تسجيل ذاتي + إدخال إداري + اعتماد/رفض.
2. Unified IDs: Customer/Farm/Flock + Case/Lot/Approval prefixes.
3. Unified Case Management foundation.
4. Flock/Farm lifecycle linkage عبر Farm/Flock + Case references (الـTimeline الموسع مستمر بالتطوير).
5. Flock creation ضمن التسجيل، مع ربط القطيع بالمزرعة.
7. Batch/Lot Tracking foundation.
13. Multi-Level Approval foundation.
26. Audit foundation للأحداث الجديدة.
28. Customer 360 header/foundation في بوابة العميل.
30. Human-in-the-Loop AI governance باقٍ من V18/V19 مع بوابة الطبيب.

## موجود سابقاً ومُحافظ عليه
6. Withdrawal/Healthy Poultry gates (V19) — تمت إضافة helper جديد لفترة السحب في lifecycle module.
8. Recall concepts/product control — الأساس موجود، واجهة Recall الشاملة ما زالت تحتاج إغلاق كامل.
9. Cold-chain flags/guards موجودة V19، وربط sensors الحقيقي يحتاج IoT.
10. Field vets/visits موجودة جزئياً V16-V19.
11. تقييم مقدمي الخدمة موجود جزئياً في بيانات الأطباء/الشركاء.
12. الشكاوى/التصعيد موجود جزئياً كCases؛ SLA المتكامل يحتاج توسيع.
14. RBAC موجود V16/V19؛ Permission granularity server-side يحتاج ترقية لاحقة.
15-17. العقود/التوقيع/انتهاء العقود موجودة جزئياً؛ Document Center موحد ما زال قيد التطوير.
18-25. توجد مكونات متفرقة (Audit/notifications/emergency/offline/procurement/forecast/backups) لكن يلزم توحيدها في دورة تشغيلية واحدة.
27. QR موجود للجواز والجودة؛ QR onboarding مضاف كمسار تصميمي وليس مولد QR مخصصاً بعد.
29. Supplier 360 توجد بياناته موزعة على الشركاء والعقود والمخزون؛ شاشة 360 موحدة ما زالت مطلوبة.

هذه الوثيقة تمنع اعتبار وجود اسم وحدة دليلاً على اكتمالها الإنتاجي.
