# Custom ProGuard/R8 rules for Smart Poultry Platform.
# Capacitor rules are supplied by its Android dependency.
