This directory is populated automatically by:
  npm run build:web
  npx cap sync android
Do not treat this source placeholder as the final application web bundle.
