# MASTER ROADMAP — V20.2.4+

## Current baseline
V20.2.4 completes the domain-level feed-factory manufacturing loop on Windows/Web while preserving V8–V20.2.3.

## V20.2.4 — Feed Factory, Procurement & Inventory Expansion — IMPLEMENTED
Raw materials → formula version → nutrient calculation/approval → manufacturing order → reservation/issue → production output/yield/loss/cost → finished goods → dispatch/receiving variance → farm feed consumption → finance/audit/report.

## V20.2.5 — HR, Payroll & Workforce + Managed Business Expansion — NEXT
Employee lifecycle, contracts, attendance/shifts, office/factory/farm assignments, multiple doctor compensation models, workers, accountants, supervisors, allowances, transport/housing, advances, deductions, bonuses, payroll, payslips, cost allocation and financial posting. Existing office/factory/farm dashboards evolve with workforce KPIs.

## V20.2.6 — Executive Intelligence & Reports
Unified executive drill-down for offices, factories, farms, veterinary, finance, inventory, sales, procurement and HR; scheduled reports, aging, profitability, production efficiency, exceptions and end-of-cycle analysis.

## V20.2.7 — Production Hardening
Production database/migrations, session/auth completion across legacy sensitive routes, security hardening, backups/restore, concurrency, performance, monitoring, error handling, accounting close controls, full automated regression/security suite and signed Windows/Web production build.

## V20.3 — Android Field Platform
Only after the Windows/Web reference platform is stable. Android consumes the same backend, roles, scope, veterinary workflow, inventory, finance and audit rules.

## Permanent backlog rule
New requirements are impact-assessed and assigned to the earliest safe version. Accepted prior requirements are never silently dropped.
